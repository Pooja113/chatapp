import express from "express";
import kafka from "kafka-node";
import mongoose from "mongoose";
const app = express();

app.use(express.json());
mongoose.connect(process.env.MONGO_URL);
const User = new mongoose.model("user", {
  name: String,
  email: String,
  password: String,
});
const dbrunning = async () => {
  const client = new kafka.KafkaClient({
    kafkaHost: process.env.KAFKA_BOOTSTRAP_SERVERS,
  });
  client.createTopics(
    [
      {
        topic: process.env.KAFKA_TOPIC,
        partitions: 1,
        replicationFactor: 1,
      },
    ],
    (error, result) => {
      console.log("error", error);
      console.log("result", result);
    }
  );
  const producer = new kafka.Producer(client);

  producer.on("ready", async () => {
    app.post("/", async (req, res) => {
      producer.send(
        [
          {
            topic: process.env.KAFKA_TOPIC,
            messages: JSON.stringify(req.body),
          },
        ],
        async (err, data) => {
          if (err) console.log("err", err);
          else {
            await User.create(req.body);
            res.send(req.body);
          }
        }
      );
    });
  });
};

setTimeout(dbrunning, 5000);

app.listen(process.env.PORT, () => {
  console.log(`Server running ${process.env.PORT} ${process.env.MONGO_URL}`);
});
