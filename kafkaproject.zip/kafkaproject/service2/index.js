import express from "express";
import kafka from "kafka-node";
import mongoose from "mongoose";
const app = express();

app.use(express.json());

mongoose.connect(process.env.MONGO_URL);
const User = new mongoose.model("user", {
  name: String,
  email: String,
  password: String,
});
const dbrunning = () => {
  const client = new kafka.KafkaClient({
    kafkaHost: process.env.KAFKA_BOOTSTRAP_SERVERS,
  });

  const consumer = new kafka.Consumer(
    client,
    [
      {
        topic: process.env.KAFKA_TOPIC,
        partition: 0,
      },
    ],
    {
      autoCommit: false,
    }
  );
  consumer.on("message", async (message) => {
    console.log("message", message);
    const newUser = await new User(JSON.parse(message.value));
    await newUser.save();
  });
  consumer.on("error", (err) => {
    console.log("err", err);
  });
};

setTimeout(dbrunning, 5000);
app.listen(process.env.PORT, () => {
  console.log(`Server running ${process.env.PORT} ${process.env.MONGO_URL}`);
});
